# sound

# Implement sharing intent in IOs

https://pub.dev/packages/receive_sharing_intent

# Maybe use a round slider
https://github.com/davidanaya/flutter-circular-slider